
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
   
    public VersionDao() {
    }
    //Agregar autor
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (Version) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la version" + e);
            return false;
        }
    }
    
    //Modificar autor
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET Version = ? WHERE idversion = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.setInt(2, version.getIdversion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la version" + e);
            return false;
        }
    }

    //Borrar autor
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE idversion = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la version" + e);
            return false;
        }
    }

    //Listar autor
    public List listarVersion(){
        List<Version> list_version = new ArrayList();
        String query = "SELECT * FROM version ORDER BY nombreversion ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdversion(rs.getInt("idversion"));
                version.setNombreVersion(rs.getString("nombreversion"));
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }    
    
    //Buscar id de autor
    public int buscarIdVersion(String nombre){
        int id = 0;
        String query = "SELECT idversion FROM version WHERE version = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idversion");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);
        }
        return id;
    }

}







