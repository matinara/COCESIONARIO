/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import view.Pantalla;

public class MarcaControlador implements ActionListener, MouseListener, KeyListener {
    public Marca marca;
    public MarcaDao marcaDao;
    public Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public MarcaControlador(Marca marca, MarcaDao marcaDao, Pantalla panta) {
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btn_Agregar_Marca.addActionListener(this);
        //Botón de modificar autor
        this.panta.btn_Modificar_Marca.addActionListener(this);
        //Botón de borrar autor
        this.panta.btn_Borrar_Marca.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Marca.addActionListener(this);
        
        //Listado de autor
        this.panta.tb_Marca.addMouseListener(this);
              
        listarMarcas(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Marca){
            //verifica si el campo nombre está vacío
            if(panta.txt_Marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                marca.setNombreMarca(panta.txt_Marca.getText());
                if(marcaDao.agregarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se agregó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la marca");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Marca){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                marca.setIdmarca(Integer.parseInt(panta.txt_Id_Marca.getText()));
                marca.setNombreMarca(panta.txt_Marca.getText());
                if(marcaDao.modificarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se modificó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la marca");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Marca){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Marca.getText());
                if(marcaDao.borrarMarca(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se eliminó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la marca");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Marca){
                limpiarTabla();
                limpiarCampos();
                listarMarcas();    
                panta.btn_Agregar_Marca.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Marca){
            int row = panta.tb_Marca.rowAtPoint(e.getPoint());
            panta.txt_Id_Marca.setText(panta.tb_Marca.getValueAt(row,0).toString());
            panta.txt_Marca.setText(panta.tb_Marca.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Marca.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarMarcas(){

        panta.cmb_Marca.removeAllItems();

        List<Marca> list = marcaDao.listarMarca();
        model = (DefaultTableModel) panta.tb_Marca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdmarca();
            row[1] = list.get(i).getNombreMarca();
            model.addRow(row);
            panta.cmb_Marca.addItem(list.get(i).getNombreMarca());
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Marca.setText("");
        panta.txt_Marca.setText("");
    }
    
}

    

