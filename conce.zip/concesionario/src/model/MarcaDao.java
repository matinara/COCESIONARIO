
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class MarcaDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

 public MarcaDao() {
    }
    //Agregar editorial
    public boolean agregarMarca(Marca marca){
        String query = "INSERT INTO marca (Marca) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la marca" + e);
            return false;
        }
    }
    
    //Modificar editorial
    public boolean modificarMarca(Marca marca){
        String query = "UPDATE marca SET Marca = ? WHERE idMarca = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getMarca());
            pst.setInt(2, marca.getIdmarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la editorial" + e);
            return false;
        }
    }

    //Borrar editorial
    public boolean borrarMarca(int id){
        String query = "DELETE FROM marca WHERE idmarca = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la marca" + e);
            return false;
        }
    }

    //Listar editorial
    public List listarMarca(){
        List<Marca> list_marcas = new ArrayList();
        String query = "SELECT * FROM marca ORDER BY marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Marca marca = new Marca();
                marca.setIdmarca(rs.getInt("idmarca"));
                marca.setMarca(rs.getString("marca"));
                list_marcas.add(marca);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_marcas;
    }    

    //Buscar id de editorial
    public int buscarIdMarca(String nombre){
        int id = 0;
        String query = "SELECT idmarca FROM marca WHERE marca = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmarca");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de marca" + e);
        }
        return id;
    }
    
}

