package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class AutoDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public AutoDao() {
    }
    //Agregar autor
    public boolean agregarAuto(Auto auto){
        String query = "INSERT INTO autor (Auto) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,auto.getNombreAuto());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el auto" + e);
            return false;
        }
    }
    
    //Modificar autor
    public boolean modificarAuto(Auto auto){
        String query = "UPDATE autor SET Auto = ? WHERE idAuto = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,auto.getNombreAuto());
            pst.setInt(2, auto.getIdauto());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el auto" + e);
            return false;
        }
    }

    //Borrar autor
    public boolean borrarAuto(int id){
        String query = "DELETE FROM autor WHERE idauto = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el autor" + e);
            return false;
        }
    }

    //Listar autor
    public List listarAutos(){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT * FROM autor ORDER BY nombreauto ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombreAuto(rs.getString("nombreauto"));
                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    }    
    
    //Buscar id de autor
    public int buscarIdAuto(String nombre){
        int id = 0;
        String query = "SELECT idauto FROM autor WHERE auto = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idauto");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de auto" + e);
        }
        return id;
    }

}



