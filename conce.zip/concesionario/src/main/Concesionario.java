
package main;

import view.Pantalla;


public class Concesionario {

    public static void main(String[] args) {
        Pantalla panta = new Pantalla();
        panta.setVisible(true);

    }
    
}
